import '../Styles/font_styles.dart';

final FontStyles fontStyles = FontStyles();
