import 'package:flutter/material.dart';

class CustomColors {
  static const primaryColor = Color(0XFF650ea0);
  static const secondaryColor = Color(0XFFae80cd);
  static const blackColor = Colors.black;
  static const whiteColor = Colors.white;
}
