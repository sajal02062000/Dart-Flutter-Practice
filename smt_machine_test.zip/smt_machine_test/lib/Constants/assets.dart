class Assets {
  static const logo = "assets/icons/logo.png";
}
