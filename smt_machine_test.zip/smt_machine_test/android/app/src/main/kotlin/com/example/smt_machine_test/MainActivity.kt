package com.example.smt_machine_test

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
